-- !preview conn=DBI::dbConnect(RSQLite::SQLite())

  -- for command line client only, can delete when finished with table creation
  USE wlcarte2; -- change to your user id
  
  DROP VIEW IF EXISTS current_active_supplier_formulations;
  DROP VIEW IF EXISTS flattened_product_bom;
  DROP VIEW IF EXISTS health_risk_violations_last_30_days;
  
  -- current active supplier formulations
  CREATE VIEW current_active_supplier_formulations AS
  SELECT 
      sf.formulation_id,
      sf.supplier_id,
      s.supplier_name,
      sf.ingredient_id,
      i.ingredient_name,
      i.ingredient_type,
      sf.version_no,
      sf.pack_size,
      sf.price_per_unit,
      sf.effective_period_start_date,
      sf.effective_period_end_date
  FROM SupplierFormulation sf
  JOIN Supplier s ON sf.supplier_id = s.supplier_id
  JOIN Ingredient i ON sf.ingredient_id = i.ingredient_id
  WHERE CURDATE() BETWEEN sf.effective_period_start_date 
      AND COALESCE(sf.effective_period_end_date, '9999-12-31');





  -- flattened bom view
  CREATE VIEW flattened_product_bom AS
  SELECT 
      rp.plan_id,
      rp.product_id,
      p.name AS product_name,
      rp.manufacturer_id,
      m.manufacturer_name,
      rp.version_no,
      rp.is_active,
      -- show both compound and atomic ingredients
      ri.ingredient_id AS bom_ingredient_id,
      i.ingredient_name AS bom_ingredient_name,
      i.ingredient_type AS bom_ingredient_type,
      ri.quantity AS bom_quantity,
      -- for atomic: show itself; for compound: show child
      COALESCE(ic.child_ingredient_id, ri.ingredient_id) AS atomic_ingredient_id,
      COALESCE(ai.ingredient_name, i.ingredient_name) AS atomic_ingredient_name,
      -- calculate atomic quantity (if compound, distribute proportionally)
      CASE 
          WHEN i.ingredient_type = 'atomic' THEN ri.quantity
          ELSE ri.quantity * ic.quantity / 
             (SELECT SUM(quantity) FROM IngredientComposition WHERE parent_ingredient_id = i.ingredient_id)
      END AS atomic_quantity_oz
  FROM RecipePlan rp
  JOIN Product p ON rp.product_id = p.product_id
  JOIN Manufacturer m ON rp.manufacturer_id = m.manufacturer_id
  JOIN RecipeIngredient ri ON rp.plan_id = ri.plan_id
  JOIN Ingredient i ON ri.ingredient_id = i.ingredient_id
  LEFT JOIN IngredientComposition ic ON i.ingredient_id = ic.parent_ingredient_id AND i.ingredient_type = 'compound'
  LEFT JOIN Ingredient ai ON ic.child_ingredient_id = ai.ingredient_id;







  -- health risk violation view
  CREATE VIEW health_risk_violations_last_30_days AS
  SELECT DISTINCT
      pb.lot_number AS product_lot_number,
      pb.product_id,
      p.name AS product_name,
      pb.manufacturer_id,
      pb.production_date,
      dnc.ingredientA_id,
      ia.ingredient_name AS ingredientA_name,
      dnc.ingredientB_id,
      ib.ingredient_name AS ingredientB_name,
    'Incompatible ingredients detected' AS violation_type
  FROM ProductBatch pb
  JOIN Product p ON pb.product_id = p.product_id
  JOIN BatchConsumption bc1 ON pb.lot_number = bc1.product_lot_number
  JOIN IngredientBatch ib1 ON bc1.ingredient_lot_number = ib1.lot_number
  JOIN BatchConsumption bc2 ON pb.lot_number = bc2.product_lot_number
  JOIN IngredientBatch ib2 ON bc2.ingredient_lot_number = ib2.lot_number
  JOIN DoNotCombine dnc ON (
      (ib1.ingredient_id = dnc.ingredientA_id AND ib2.ingredient_id = dnc.ingredientB_id) OR
      (ib1.ingredient_id = dnc.ingredientB_id AND ib2.ingredient_id = dnc.ingredientA_id)
  )
  JOIN Ingredient ia ON dnc.ingredientA_id = ia.ingredient_id
  JOIN Ingredient ib ON dnc.ingredientB_id = ib.ingredient_id
  WHERE pb.production_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
    AND bc1.ingredient_lot_number < bc2.ingredient_lot_number; -- avoid duplicates