# NCSU_CSC540_Project
# CSC 540 – Food Manufacturing Database Project  


=================================================
FOOD MANUFACTURING SYSTEM - DATABASE PROJECT
=================================================

Evie Kenna  
Taylor Burke  
Will Carter  
Brett Hinkle  

==========================
PROJECT DESCRIPTION
==========================

A comprehensive food manufacturing system that manages the entire production
lifecycle. The system supports multiple manufacturers and suppliers, tracking ingredient batches, recipe plans, production batches, and full supply chain traceability for recall scenarios.


========================
PROJECT STRUCTURE
========================

YourProject/
|-- DBConnect/
│   |-- src/                      
│   │   |-- Main.java            
│   │   |-- DBConnect.java       
│   │   |-- ManufacturerMenu.java
│   │   |-- SupplierMenu.java
│   │   |-- ViewerMenu.java
│   │   |-- ProductService.java
│   │   |-- RecipeService.java
│   │   |-- ProductionService.java
│   │   |-- IngredientService.java
│   |-- bin/                      
│   |-- FoodManufacturing.jar    Executable JAR file
|   |-- manifest.txt
|-- sql/
│   |-- SQL_CREATE_TABLE.sql        
│   |-- INSERTS.sql              
|-- README.txt              


================================================================================
DATABASE SETUP
================================================================================

1. In terminal, navigate to project folder and connect to mariadb server and enter password:
   mysql -h classdb2.csc.ncsu.edu -P 3306 -u wlcarte2 -p --ssl=0

2. Use the database:
   USE wlcarte2;

3. Navigate to project folder execute sql files:
   SOURCE sql/CREATE_TABLES.sql;

4. Load sample data:
   SOURCE sql/INSERTS.sql;


=============================
HOW TO RUN THE APPLICATION
=============================

Run JAR File
-----------
1. Navigate to DBConnect directory:
   cd DBConnect/

2. Run the executable:
   java -jar FoodManufacturing.jar


=============================
NOTES
=============================
See the report (`CSC_540_Database_Design_Report(1).pdf`) and ER diagram (`Final ER Diagram.pdf`) for full documentation.
